package br.com.fiap.am.druida.bean;

import br.com.fiap.am.druida.bean.Pessoa;

public class Advogado extends Pessoa {

	private int codigoAdvogado;

	public int getCodigoAdvogado() {
		return codigoAdvogado;
	}

	public void setCodigoAdvogado(int codigoAdvogado) {
		this.codigoAdvogado = codigoAdvogado;
	}

}
