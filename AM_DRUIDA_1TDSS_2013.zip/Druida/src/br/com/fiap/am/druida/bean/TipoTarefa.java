package br.com.fiap.am.druida.bean;

public class TipoTarefa {

	private short codigoTarefa;
	private String tipoTarefa;

	public short getCodigoTarefa() {
		return codigoTarefa;
	}

	public void setCodigoTarefa(short codigoTarefa) {
		this.codigoTarefa = codigoTarefa;
	}

	public String getTipoTarefa() {
		return tipoTarefa;
	}

	public void setTipoTarefa(String tipoTarefa) {
		this.tipoTarefa = tipoTarefa;
	}

}
