package br.com.fiap.am.druida.advocacia;

public class AdvocaciaException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public AdvocaciaException() {
		super();
	}
	
	public AdvocaciaException(String msg) {
		super(msg);
	}
	

}
