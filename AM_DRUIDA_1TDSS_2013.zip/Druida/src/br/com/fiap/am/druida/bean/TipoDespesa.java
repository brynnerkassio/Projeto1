package br.com.fiap.am.druida.bean;

public class TipoDespesa {

	private short codigoDespesa;
	private String tipoDespesa;

	public short getCodigoDespesa() {
		return codigoDespesa;
	}

	public void setCodigoDespesa(short codigoDespesa) {
		this.codigoDespesa = codigoDespesa;
	}

	public String getTipoDespesa() {
		return tipoDespesa;
	}

	public void setTipoDespesa(String tipoDespesa) {
		this.tipoDespesa = tipoDespesa;
	}

}
